﻿<!--
NET AUTO-SAVE PROJECT
COMP90055 COMPUTING PROJECT(25pt)
Author: Tianjiao Cao
Author ID: 863563
29/05/2018
-->

<!--
when a user fills in the form and clicks the “submit” button 
the HTML web form data will be send to the web server "SurgeryServer.php", 
and the processing result will be returned and shown to the user. 
-->

<html>
<body>

<?php
	
	$db_host = 'localhost:3306'; // Server Name
	$db_user = 'root'; // Username
	$db_pass = 'leslie900613'; // Password
	$db_name = 'surgery_db'; // Database Name

	$con = mysqli_connect("localhost:3306","root","leslie900613","surgery_db");

	//check connection
	if (!$con)
	{
		die('Could not connect: ' . mysqli_connect_error());
	}
	
	//insert the result into the database
	$sql="INSERT INTO surgery (SurgeryDate, SurgeryType, Performed, 
	Aim, ResectionPathology, ResectionSpecimen, ResectionPathologyGrade, 
	Comment, VisitSchedule)
	VALUES('$_POST[SurgeryDate]','$_POST[SurgeryType]','$_POST[Performed]',
	'$_POST[Aim]','$_POST[ResectionPathology]','$_POST[ResectionSpecimen]',
	'$_POST[ResectionPathologyGrade]','$_POST[Comment]','$_POST[VisitSchedule]')";

		
	
	if (mysqli_query($con, $sql)) {
	
		echo"<script>alert('1 record added.');history.go(-1);</script>";
		echo "<script type='text/javascript'> reset(); </script>";
;
	} 
	else {
		
		echo "Error: " . $sql . "<br>" . mysqli_error($con);
	}

	mysqli_close($con);
	//}
	
	

?>

</body>
</html>